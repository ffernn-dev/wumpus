"Tuft of grass by Poly by Google [CC-BY]" (https://creativecommons.org/licenses/by/3.0/) via Poly Pizza (https://poly.pizza/m/3tyh15Fbmsx)
Wumpus model modified from "Blue Demon by Quaternius" (https://poly.pizza/m/S7jYW6Amye)
DataArrow model modofied from "Arrow by Quaternius" (https://poly.pizza/m/Rt48KEPDGt)
Glasses by iPoly3D (https://poly.pizza/m/YchMXfQNU0)
Glitch shader from https://godotshaders.com/shader/glitch-effect-shader/
